package main

//使用gorm时，除了导入gorm包，还要导入数据库驱动
import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

func main() {
	//使用gorm连接数据库
	//1、定义数据库地址
	// - charset 字符编码类型
	// - parseTime 是否自动解析时间类型  time.Time
	// - loc 时间分区
	dsn := "root:123456@tcp(127.0.0.1:3306)/test_db?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	fmt.Println(db)

	//自动创建表
	//1、定义mapping结构体
	//2、基于结构体创建表

	db.AutoMigrate(User{})
}
//在没有自定义表名的情况下，数据库生成的表名是结构体名字的复数
type User struct {
	Id int64 `gorm:"primary_key" json:"id"`
	Username string `gorm:"column:user"`
	Password string
}

// 结构体属性 => 表字段
//Username => username
//UserName => user_name
//Username => user

//自定义表名
func(User) TableName() string {
	return "people"
}