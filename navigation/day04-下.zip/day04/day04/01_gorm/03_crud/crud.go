package main

//使用gorm时，除了导入gorm包，还要导入数据库驱动
import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type User struct {
	Id int64 `gorm:"primary_key" json:"id"`
	Username string `gorm:"column:username"`
	Password string
}

func main() {
	//使用gorm连接数据库
	//1、定义数据库地址
	// - charset 字符编码类型
	// - parseTime 是否自动解析时间类型  time.Time
	// - loc 时间分区
	dsn := "root:123456@tcp(127.0.0.1:3306)/test_db?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	fmt.Println(db)

	//创建表
	db.AutoMigrate(User{})

	//新增
	//db.Create(&User{
	//	Username: "zhangsan",
	//	Password: "123456",
	//})
	//错误处理： if tx.Error != nil && tx.Error != gorm.ErrRecordNotFound {}

	//修改
	//把user表中id为1的这条数据的username改为lisi
	//这里的model有两个功能
	//1、指定映射关系的结构体（找到对应的表）
	//2、找到这条数据,相当于 where id = 1
	db.Model(User{Id:1}).Update("username", "lisi")
	//使用where指定数据并修改
	db.Model(User{}).Where("id = ?", 2).Update("username", "wangwu")
	//db.Table("users").Where("id = ?", 2).Update("username", "wangwu")

	//查询
	u := &User{
		Id:1,
	}
	u1 := &User{}
	fmt.Println(u)
	db.First(u)
	fmt.Println(u)
	db.Debug().Where("id = ?", 2).First(u1) //debug，打印sql日志
	fmt.Println(u1)
	//多条查询
	users := []User{}
	db.Where("id in (?)", []int64{1, 2}).Find(&users)
	fmt.Println(users)

	//删除
	//db.Delete(&User{Id: 1})
	db.Where("Id = ?", 2).Delete(User{})
}
