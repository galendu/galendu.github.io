package main

//使用gorm时，除了导入gorm包，还要导入数据库驱动
import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

//定义一对多关系的结构体
type User struct {
	gorm.Model
	Username string
	//该字段不会真正在数据库种创建
	//什么情况下需要定义这个属性呢？并不是说存在一对多关系，就一定需要这个属性
	//而是看需求场景，若user和creaditcard是一对多关系，且在查询user时，需要把
	//user下的creaditcard也查询出来时，则需要这个字段，gorm会帮忙处理关联操作
	CreditCards []*CreditCard
}

type CreditCard struct {
	gorm.Model
	Number string
	UserId uint //外键，user表或结构体的id
}

//自定义外键关联
//type User struct {
//	gorm.Model
//	MemberNumber string `gorm:"index"`
//	//tag描述：creditcard的外键名是user_number，对应的外键值是user中的member_number
//	CreditCards  []CreditCard `gorm:"foreignKey:UserNumber;references:MemberNumber"`
//}
//
//type CreditCard struct {
//	gorm.Model
//	Number     string
//	UserNumber string `gorm:"index"`
//}

func main() {
	//使用gorm连接数据库
	//1、定义数据库地址
	// - charset 字符编码类型
	// - parseTime 是否自动解析时间类型  time.Time
	// - loc 时间分区
	dsn := "root:123456@tcp(127.0.0.1:3306)/test_db?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	fmt.Println(db)

	db.AutoMigrate(User{}, CreditCard{})

	//创建数据，关联创建
	//user := &User{
	//	Username:    "zhangsan",
	//	CreditCards: []*CreditCard{
	//		{Number: "10001"},
	//		{Number: "10002"},
	//	},
	//}
	//db.Create(user)
	user1 := &User{}
	db.Where("username = ?", "zhangsan").First(user1)
	fmt.Println(user1)

	//关联查询
	//查询user1表中的关联数据Creditcards，然后放数据放到user1.CreditCards中
	db.Model(user1).Association("CreditCards").Find(&user1.CreditCards)
	fmt.Println(user1)
	//关联追加
	db.Model(user1).Association("CreditCards").Append([]*CreditCard{
		{Number: "10003"},
	})

	//preload关联查询
	user2 := &User{}
	db.Preload("CreditCards").Where("username = ?", "zhangsan").First(user2)
	fmt.Println(user2)

	//preload和association的uebie
	//1、preload仅支持查询，association支持关联的增删改查
	//2、preload会把user和creaditcard的查询并成一步去处理，更加方便
	//3、一般情况下，列表查询使用preload，关联的增删改查使用association
}
