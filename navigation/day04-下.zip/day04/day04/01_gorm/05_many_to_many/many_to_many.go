package main

//使用gorm时，除了导入gorm包，还要导入数据库驱动
import (
	"encoding/json"
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"time"
)

//创建多对多关系结构体
//type Student struct {
//	gorm.Model
//	Language []*Language `gorm:"many2many:user_languages"`
//}
//
//type Language struct {
//	gorm.Model
//	Name string
//}

//type User struct {
//	gorm.Model
//	Profiles []Profile `gorm:"many2many:user_profiles;foreignKey:Refer;joinForeignKey:UserReferID;References:UserRefer;joinReferences:ProfileRefer"`
//	Refer    uint      `gorm:"index:,unique"`
//}
//
//type Profile struct {
//	gorm.Model
//	Name      string
//	UserRefer uint `gorm:"index:,unique"`
//}

type Person struct {
	Id int
	Name string
	Addresses []*Address `gorm:"many2many:person_addresses;"`
}

type Address struct {
	Id int
	Name string
}

type PersonAddress struct {
	PersonId int `gorm:"primaryKey"`
	AddressId int `gorm:"primaryKey"`
	CreatedAt time.Time
	DeleteAt gorm.DeletedAt
}

func main() {
	//使用gorm连接数据库
	//1、定义数据库地址
	// - charset 字符编码类型
	// - parseTime 是否自动解析时间类型  time.Time
	// - loc 时间分区
	dsn := "root:123456@tcp(127.0.0.1:3306)/test_db?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	fmt.Println(db)

	db.AutoMigrate(Person{}, Address{}, PersonAddress{})
	
	//创建
	person := &Person{
		Name:      "zhangsan",
		Addresses: []*Address{
			{Id: 1, Name: "bj"},
			{Id: 2, Name: "sh"},
		},
	}
	db.Create(person)
	
	//多对多preload
	persons := []*Person{}
	db.Preload("Addresses").Find(&persons)
	personsByte, _ := json.Marshal(&persons)
	fmt.Println(string(personsByte))
}
