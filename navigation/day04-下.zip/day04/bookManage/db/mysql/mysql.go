package mysql

import (
	"bookManage/model"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)


//mysql初始化
//定义全局变量，dao层在做数据库CRUD操作时，会使用这个db实例
var DB *gorm.DB

func InitMysql() {
	dsn := "root:123456@tcp(127.0.0.1:3306)/books?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	//这里一定不能使用:=，因为这么写这里的DB就变成了局部变量，这里的DB和上面var DB是两个变量
	//后面dao层对数据库操作时会报空指针
	DB = db
	err = DB.AutoMigrate(model.User{},model.Book{},model.BookUser{})
	if err != nil {
		panic(err)
	}
}