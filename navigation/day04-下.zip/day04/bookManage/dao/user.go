package dao

import (
	"bookManage/db/mysql"
	"bookManage/model"
	"errors"
	"github.com/wonderivan/logger"
	"gorm.io/gorm"
)

var User user

type user struct{}

//新增用户
func(*user) Add(user *model.User) error {
	tx := mysql.DB.Create(&user)
	if tx.Error != nil {
		logger.Error("添加用户失败,", tx.Error)
		return tx.Error
	}

	return nil
}

//基于用户名查询用户
func(*user) GetByUsername(username string) (*model.User, bool, error) {
	data := &model.User{}
	tx := mysql.DB.Where("username = ?", username).First(data)
	if errors.Is(tx.Error, gorm.ErrRecordNotFound) {
		return nil, false, nil
	}
	if tx.Error != nil {
		logger.Error("基于用户名查询用户失败,", tx.Error)
		return nil, false, tx.Error
	}
	return data, true, nil
}

//基于token查询用户
func(*user) GetByToken(token string) (*model.User, bool, error) {
	data := &model.User{}
	tx := mysql.DB.Where("token = ?", token).First(data)
	if errors.Is(tx.Error, gorm.ErrRecordNotFound) {
		return nil, false, nil
	}
	if tx.Error != nil {
		logger.Error("基于token查询用户失败,", tx.Error)
		return nil, false, tx.Error
	}
	return data, true, nil
}

//生成/更新token，登录的时候
func(*user) UpdateToken(user *model.User, token string) error {
	tx := mysql.DB.Model(user).Where("username = ? and password = ?", user.Username, user.Password).Update("token", token)
	if tx.Error != nil {
		logger.Error("更新token失败,", tx.Error)
		return tx.Error
	}
	return nil
}