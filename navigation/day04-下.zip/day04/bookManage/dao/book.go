package dao

import (
	"bookManage/db/mysql"
	"bookManage/model"
	"errors"
	"github.com/wonderivan/logger"
	"gorm.io/gorm"
)

//service: dao.Book.List()

var Book book

type book struct{}

//列表
func(*book) List() ([]*model.Book, error) {
	books := []*model.Book{}
	//关联查询
	tx := mysql.DB.Preload("Users").Find(&books)
	if tx.Error != nil {
		logger.Error("查询书籍列表失败", tx.Error)
		return nil, tx.Error
	}

	return books, nil
}

//查询单个
//-基于书名查询
func(*book) GetByName(name string) (*model.Book, bool, error) {
	data := &model.Book{}
	tx := mysql.DB.Where("name = ?", name).First(data)
	if errors.Is(tx.Error, gorm.ErrRecordNotFound) {
		return nil, false, nil
	}
	if tx.Error != nil {
		logger.Error("基于书名查询书籍失败,", tx.Error)
		return nil, false, tx.Error
	}

	return data, true, nil
}

//-基于ID查询
func(*book) GetById(id int) (*model.Book, bool, error) {
	data := &model.Book{}
	tx := mysql.DB.Where("id = ?", id).First(data)
	if errors.Is(tx.Error, gorm.ErrRecordNotFound) {
		return nil, false, nil
	}
	if tx.Error != nil {
		logger.Error("基于书名查询书籍失败,", tx.Error)
		return nil, false, tx.Error
	}

	return data, true, nil
}

//新增
func(*book) Add(book *model.Book) error {
	//一对多或多对多，创建时如果book中有user数据，会自动关联创建user数据
	//omit:跳过关联数据的创建
	tx := mysql.DB.Omit("Users").Create(&book)
	if tx.Error != nil {
		logger.Error("创建书籍失败,", tx.Error)
		return tx.Error
	}
	//书籍关联用户
	if len(book.Users) > 0 {
		err := mysql.DB.Model(book).Association("Users").Append(book.Users)
		if err != nil {
			logger.Error("关联新增数据用户失败,", err)
			return err
		}
	}

	return nil
}

//修改
func(*book) Update(book *model.Book) error {
	tx := mysql.DB.Model(&model.Book{}).Where("id = ?", book.Id).Updates(&book)
	if tx.Error != nil {
		logger.Error("更新书籍失败,", tx.Error)
		return tx.Error
	}
	//关联更新
	if len(book.Users) > 0 {
		err := mysql.DB.Model(&book).Association("Users").Replace(book.Users)
		if err != nil {
			logger.Error("关联更新书籍用户失败,", err)
			return err
		}
	} else {
		err := mysql.DB.Model(&book).Association("Users").Clear()
		if err != nil {
			logger.Error("关联更新书籍用户失败,", err)
			return err
		}
	}

	return nil
}

//删除
func(*book) Delete(id int) error {
	data := &model.Book{
		Id:    id,
	}
	//先删除关联关系，再删除书籍主数据
	//因为先删除书籍数据后，无法再基于书籍ID去删除关联关系
	err := mysql.DB.Model(data).Association("Users").Clear()
	if err != nil {
		logger.Error("关联删除书籍用户失败,", err)
		return err
	}
	tx := mysql.DB.Delete(data)
	if tx.Error != nil {
		logger.Error("删除书籍失败,", tx.Error)
		return tx.Error
	}

	return nil
}