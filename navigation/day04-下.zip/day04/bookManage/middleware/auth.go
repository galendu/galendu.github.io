package middleware

import (
	"bookManage/dao"
	"github.com/gin-gonic/gin"
	"net/http"
)

func AuthMiddleWare() gin.HandlerFunc {
	return func(c *gin.Context) {
		token := c.GetHeader("token")
		if len(token) == 0 {
			c.JSON(http.StatusOK, gin.H{
				"code": 90403,
				"msg": "token invalid",
				"data": nil,
			})
			c.Abort()
			return
		}
		user, exsit, err := dao.User.GetByToken(token)
		if err != nil {
			c.JSON(http.StatusOK, gin.H{
				"code": 90500,
				"msg": err.Error(),
				"data": nil,
			})
			c.Abort()
			return
		}
		if !exsit {
			c.JSON(http.StatusOK, gin.H{
				"code": 90403,
				"msg": "token invalid",
				"data": nil,
			})
			c.Abort()
			return
		}
		//将用户信息存到上下文中，后面业务如果需要用到，可以到context中去拿
		c.Set("user_id", user.Id)
		//c.GetInt("user_id")
	}
}
