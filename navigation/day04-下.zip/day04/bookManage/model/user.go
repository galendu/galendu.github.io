package model

type User struct {
	Id int `gorm:"primary_key" json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
	Token string `json:"token"`
}

func(User) TableName() string {
	return "user"
}
