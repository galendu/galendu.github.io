package model

type BookUser struct {
	UserId int64 `gorm:"primary_key"`
	BookId int64 `gorm:"primary_key"`
}

func(BookUser) TableName() string {
	return "book_users"
}