package service

import (
	"bookManage/dao"
	"bookManage/model"
	"errors"
)

//controller: service.Book.List()

var Book book

type book struct {}

//列表
func(*book) List() ([]*model.Book, error) {
	return dao.Book.List() //返回值相同的情况下，可以直接返回方法
}

//查询单个
func(*book) Get(id int) (*model.Book, bool, error) {
	return dao.Book.GetById(id)
}

//新增
func(*book) Add(book *model.Book) error {
	_, exist, err := dao.Book.GetByName(book.Name)
	if err != nil {
		return err
	}
	if exist {
		return errors.New("book has already exist:" + book.Name)
	}
	return dao.Book.Add(book)
}

//更新
func(*book) Update(book *model.Book) error {
	data, exist, err := dao.Book.GetByName(book.Name)
	if err != nil {
		return err
	}
	if exist && data.Id != book.Id {
		return errors.New("book has already exist:" + book.Name)
	}
	return dao.Book.Update(book)
}

//删除
func(*book) Delete(id int) error {
	return dao.Book.Delete(id)
}