package service

import (
	"bookManage/dao"
	"bookManage/model"
	"errors"
	"github.com/google/uuid"
)

var User user

type user struct{}

//注册
func(*user) Add(user *model.User) error {
	_, exist, err := dao.User.GetByUsername(user.Username)
	if err != nil {
		return err
	}

	if exist {
		return errors.New("user has already exist:" + user.Username)
	}

	return dao.User.Add(user)
}

//登录
func(*user) Login(username, password string) error {
	data, exist, err := dao.User.GetByUsername(username)
	if err != nil {
		return err
	}
	if !exist {
		return errors.New("user is not exist:" + username)
	}
	if data.Password != password {
		return errors.New("invalid username or password")
	}

	token := uuid.New().String()
	return dao.User.UpdateToken(data, token)
}

