package main

import (
	"bookManage/controller"
	"bookManage/db/mysql"
	"github.com/gin-gonic/gin"
)

func main() {
	//初始化数据库
	mysql.InitMysql()
	//初始化gin
	r := gin.Default()
	//注册路由
	controller.Router.InitApiRouter(r)
	//启动server
	r.Run(":8888")
}
