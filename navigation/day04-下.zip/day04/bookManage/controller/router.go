package controller

import (
	"bookManage/middleware"
	"github.com/gin-gonic/gin"
)

var Router router

type router struct{}

func(*router) InitApiRouter(r *gin.Engine) {
	r.POST("/register", User.Register)
	r.POST("/login", User.Login)

	book := r.Group("/api/book")
	book.Use(middleware.AuthMiddleWare())
	book.GET("/list", Book.List)
	book.GET("/get", Book.Get)
	book.POST("/add", Book.Add)
	book.POST("/update", Book.Update)
	book.POST("/delete", Book.Delete)

	//RESTFUL 查：GET 新增：POST 修改：PUT 删除：DELETE
}