package controller

import(
	"bookManage/model"
	"bookManage/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

var Book book

type book struct{}

//列表
func(*book) List(c *gin.Context) {
	data, err := service.Book.List()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "获取书籍列表成功",
		"data": data,
	})
}

//新增
func(*book) Add(c *gin.Context) {
	param := &model.Book{}
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	if err := service.Book.Add(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "创建书籍成功",
		"data": nil,
	})
}

//获取单个
func(*book) Get(c *gin.Context) {
	param := new(struct{
		Id int `form:"id"`
	})
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	data, _, err := service.Book.Get(param.Id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "获取书籍成功",
		"data": data,
	})
}

//更新
func(*book) Update(c *gin.Context) {
	param := &model.Book{}
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	if err := service.Book.Update(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "更新书籍成功",
		"data": nil,
	})
}

//删除
func(*book) Delete(c *gin.Context) {
	param := new(struct{
		Id int `json:"id"`
	})
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	err := service.Book.Delete(param.Id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "删除书籍成功",
		"data": nil,
	})
}