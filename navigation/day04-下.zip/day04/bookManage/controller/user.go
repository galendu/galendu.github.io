package controller

import (
	"bookManage/model"
	"bookManage/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

var User user

type user struct{}

//注册
func(*user) Register(c *gin.Context) {
	param := &model.User{}
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	if err := service.User.Add(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "注册成功",
		"data": nil,
	})
}

//登录
func(*user) Login(c *gin.Context) {
	param := new(struct{
		Username string `json:"username"`
		Password string `json:"password"`
	})
	if err := c.Bind(param); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90400,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	if err := service.User.Login(param.Username, param.Password); err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code": 90500,
			"msg": err.Error(),
			"data": nil,
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"msg": "登录成功",
		"data": nil,
	})
}